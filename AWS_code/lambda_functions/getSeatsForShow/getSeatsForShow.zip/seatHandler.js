const mysql = require('mysql2/promise');
const db_access = require('/opt/db_access/db_access');
const sectionHandler = require('./sectionHandler');

async function createSeats(blockInfo) {

    const price = blockInfo.price;
    const startRow = blockInfo.startRow;
    const endRow = blockInfo.endRow;
    const sectionId = blockInfo.sectionId;
    const blockId = blockInfo.blockId;

    const sectionDetails = await sectionHandler.getSectionDetails(sectionId);
    const columns = Number(sectionDetails.columns);

    const pool = mysql.createPool({
        host: db_access.config.host,
        user: db_access.config.user,
        password: db_access.config.password,
        database: db_access.config.database,
        connectionLimit: 20,
    });

    const connection = await pool.getConnection();

    try {
        for (let row = startRow; row <= endRow; row++) {
            for (let column = 0; column < columns; column++) {
                const sql = 'INSERT INTO Ticketing.seat (price, seat.row, seat.column, block_id, section_id) VALUES (?, ?, ?, ?, ?)';
                const values = [price, row, column, blockId, sectionId];

                const [result, fields] = await connection.execute(sql, values);
            }
        }

    } catch (error) {
        return error;
    } finally {
        pool.end();
    }
}

async function purchaseSeats(arrayOfSeats){
    //given an array of seats, change all of their 'available fields from 1 to 0
    //need an error catch for if the array is empty, throw 'purchase failed, no seats selected'

    const pool = mysql.createPool({
        host: db_access.config.host,
        user: db_access.config.user,
        password: db_access.config.password,
        database: db_access.config.database,
        connectionLimit: 20,
    });

    const connection = await pool.getConnection();

    try {
        let purchasedSeats = 'successfully purchased seats: '
        let unpurchasedSeats = 'failed to purchase seats '
        let purchasedCount = 0
        let unpurchasedCount = 0
        if (arrayOfSeats.length < 1) { throw new Error('no seats selected'); }

        for (let i = 0; i < arrayOfSeats.length; i++) {
            const seatId = arrayOfSeats[i].id;
            const isTheSeatAvailable = await isSeatAvailable(seatId);

            if (isTheSeatAvailable) {
                const sql = 'Update Ticketing.seat SET available = 0 WHERE id = ?';
                const [result, fields] = await connection.execute(sql, [seatId]); 
                
                purchasedCount++;
                purchasedSeats = purchasedSeats + seatId + ', ';
            } else {
                unpurchasedCount++;
                unpurchasedSeats = unpurchasedSeats + seatId + ', ';
            }
            
        }

        if (purchasedCount > 0 && unpurchasedCount > 0) {
            return purchasedSeats + '\n' + unpurchasedSeats;
        } else if (purchasedCount > 0 && !(unpurchasedCount > 0)) {
            return purchasedSeats;
        } else if (!(purchasedCount > 0) && unpurchasedCount > 0) {
            return unpurchasedSeats;
        } else {
            return 'No seats selected';
        }

    } catch (error) {
        console.error('unable to purchase seats: ' + error);
    } finally {
        pool.end();
    }

}

async function isSeatAvailable(seatId) {

    const pool = mysql.createPool({
        host: db_access.config.host,
        user: db_access.config.user,
        password: db_access.config.password,
        database: db_access.config.database,
        connectionLimit: 20,
    });

    const connection = await pool.getConnection();

    try {
        const sql = 'SELECT available FROM Ticketing.seat WHERE id = ?';
        const [result, fields] = await connection.execute(sql, [seatId]);

        if (result.length > 0) {
            return result[0].available === 1;
        } else {
            return false;
        }
    } catch (error) {
        console.error('error checking seat availability: ' + error);
    } finally {
        pool.end();
    }
}

async function createSeatsForSection(blockInfo, blockId) {

    const pool = mysql.createPool({
        host: db_access.config.host,
        user: db_access.config.user,
        password: db_access.config.password,
        database: db_access.config.database,
        connectionLimit: 20,
    });

    const connection = await pool.getConnection();

    try{
    
    if (!blockInfo || !blockInfo.rows || !blockInfo.columns) {
            console.error('Invalid blockInfo:', blockInfo);
            return;
        }

    let seatString = 'here are all the seat Ids: ';

        for (let row = 1; row <= blockInfo.rows; row++) {
            for (let column = 1; column <= blockInfo.columns; column++) {
                const sql = 'INSERT INTO Ticketing.seat (price, `row`, `column`, available, section_id) VALUES (?, ?, ?, ?, ?)';
                const values = [0, row, column, 0, blockId];

                const [result, fields] = await connection.execute(sql, values);

                console.log('Inserting seat with values: ' + values);

                seatString += result.insertId + ',';
            }
        }

        return seatString;

    } catch (error) {
        console.error('Error during seat creation:', error);
    } finally {
        pool.end();
    }
}

async function getSeatsForShow(event) {

    const showId = Number(event.showId);

    const pool = mysql.createPool({
        host: db_access.config.host,
        user: db_access.config.user,
        password: db_access.config.password,
        database: db_access.config.database,
        connectionLimit: 20,
    });

    const connection = await pool.getConnection();

    try {

        const seats = [];

        // Get each block in the show
        const searchBlocksSQL = 'SELECT * FROM Ticketing.block WHERE block.show_id = ?';
        const [blockResult, blockFeilds] = await connection.execute(searchBlocksSQL, [showId]);

        const blockIds = [];

        for (const block of blockResult) {
            blockIds.push(block.id);
        }

        // Get each seat in the blocks
        const searchSeatsSQL = 'SELECT * FROM Ticketing.seat WHERE seat.block_id = ?';

        for (const id of blockIds) {
            const [seatResult, seatFeilds] = await connection.execute(searchSeatsSQL, [id]);
            seats.push(seatResult);
        }

        // Return all the seats
        return seats;

    } catch (error) {
        return error;
    } finally {
        pool.end();
    }
}

module.exports = { createSeats, getSeatsForShow };
