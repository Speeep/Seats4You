const mysql = require('mysql2/promise');
const db_access = require('/opt/db_access/db_access');
// const showHandler = require('./showHandler');

// Ensures that the number is an integer greater than 0.
function isValidNumber(value) {
    value = Number(value);
    return isFinite(value) && Math.floor(value) === value && value > 0;
}

// Ensures that the number is an double greater than 0.
function isValidDouble(value) {
    return isFinite(value) && value > 0;
}

async function createBlock(event) {
    const rows = Number(event.rows);
    const price = Number(event.price);
    const show = Number(event.show_id);
    const section = Number(event.section_id);
    console.log('Creating block with rows:', rows, 'at price:', price , 'for show: ', show, 'in section: ', section);

    if (!isValidNumber(rows)) {
        return 'Invalid rows value';
    }

    if (!isValidDouble(price)) {
        return 'Invalid price value';
    }

    if (!isValidNumber(show)) {
        return 'Invalid show id value';
    }

    if (!isValidNumber(section)) {
        return 'Invalid section id value';
    }

    const pool = mysql.createPool({
        host: db_access.config.host,
        user: db_access.config.user,
        password: db_access.config.password,
        database: db_access.config.database,
        connectionLimit: 20,
    });

    const connection = await pool.getConnection();

    try {

        // TODO: Implement Show Existence checking (Not spelled correctly below)
        // if (!(await showHandler.checkShowExistense(show))) {
        //     throw new Error('Show does not exist, please try a different ID.');
        // }

        const sql = 'INSERT INTO Ticketing.block (block.rows, block.price, block.show_id, block.section_id) VALUES (?, ?, ?, ?)';
        const values = [rows, price, show, section];

        console.log('Executing SQL:', sql, 'with values:', values);

        const [result, fields] = await connection.execute(sql, values);

        return result.insertId;

    }  catch (error) {
        return error;
    }  finally {
        connection.release();
    }
}

async function deleteBlock(event) {

    const blockId = Number(event.blockId);

    if (!isValidNumber(blockId)) {
        return 'Invalid blockId value';
    }

    const pool = mysql.createPool({
        host: db_access.config.host,
        user: db_access.config.user,
        password: db_access.config.password,
        database: db_access.config.database,
        connectionLimit: 20,
    });

    const connection = await pool.getConnection();

    try {

        if (blockId) {
            const deleteBlockSql = 'DELETE FROM Ticketing.block WHERE block.id = ?';
            const [result, fields] = await connection.execute(deleteBlockSql, [blockId]);
            if (result.affectedRows > 0) {
                return blockId
            } else {
                return 'Invalid blockId value'
            }
        }
    } catch (error) {
        return error;
    } finally {
        pool.end();
    }
}

async function deleteBlocksOfShow(event) {
    const showId = Number(event.showId);

    const pool = mysql.createPool({
        host: db_access.config.host,
        user: db_access.config.user,
        password: db_access.config.password,
        database: db_access.config.database,
        connectionLimit: 20,
    });

    const connection = await pool.getConnection();

    try {
        if (showId) {
            const deleteAllBlocksSql = 'DELETE FROM Ticketing.block WHERE block.show_id = ?';
            const [result, fields] = await connection.execute(deleteAllBlocksSql, [showId]);
            if (result.affectedRows > 0) {
                return showId
            } else {
                return 'Invalid showId value'
            }
        }
    } catch (error) {
        return error;
    } finally {
        pool.end();
    }
}

//listblocks
async function listBlocksOfShow(blockId){
    const showId = blockId.show_id

    const pool = mysql.createPool({
        host: db_access.config.host,
        user: db_access.config.user,
        password: db_access.config.password,
        database: db_access.config.database,
        connectionLimit: 20,
    });

    const connection = await pool.getConnection();

    try {
        const listBlocksSql = 'SELECT * FROM Ticketing.block WHERE block.show_id = ?';
        const [result, fields] = await connection.execute(listBlocksSql, [showId]);

        return result


    } catch (error) {
        console.error('Error:', error);
    } finally {
        pool.end();
    }
}

module.exports = { createBlock, deleteBlock, deleteBlocksOfShow, listBlocksOfShow };