
module.exports = {
    // DB Credentials
    config : {
        "host" : "ticketing.cnuwe9gh28u7.us-east-2.rds.amazonaws.com",
        "user" : "TicketAdmin",
        "password" : "HsnY2mW!JPQ9",
        "database" : "Ticketing"
    }
}
